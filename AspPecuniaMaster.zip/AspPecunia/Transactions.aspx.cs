﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading.Tasks;

namespace AspPecunia
{
    public partial class Transactions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void slip_Click(object sender, EventArgs e)
        {
            Response.Redirect("SlipTransaction.aspx");
        }

        protected void cheque_Click(object sender, EventArgs e)
        {


            Response.Redirect("ChequeTransaction.aspx");
        }

       

        protected async void search_Click(object sender, EventArgs e)
        {
            TransactionBL transactionBL = new TransactionBL();
            Guid accountID;
            Guid.TryParse(searchBox.Text, out accountID);
            List<Transaction> transactions = await transactionBL.DisplayTransactionByAccountIDBL(accountID);
            allTransactions.DataSource = transactions;
            allTransactions.DataBind();
        }

        
    }
}