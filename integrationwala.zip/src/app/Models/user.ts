export class User {
  email: string;
  name: string;

  constructor(Email: string, Name: string) {
    this.email = Email;
    this.name = Name;
  }
}
