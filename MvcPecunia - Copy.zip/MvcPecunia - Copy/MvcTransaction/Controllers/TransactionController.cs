﻿
using Capgemini.Pecunia.Entities;
using MvcTransaction.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Capgemini.Pecunia.BusinessLayer;
using Pecunia.Entities;
using System.Threading.Tasks;

namespace MvcTransaction.Controllers
{
    public class TransactionController : Controller
    {
        //URL: Transaction/ChequeTransactions
        public ActionResult ChequeTransactions()
        {
            //Creating and initializing viewmodel object
            TransactionViewModel transactionViewModel = new TransactionViewModel()
            {
                TransactionID = Guid.NewGuid(),
                Mode = "Cheque"
            };
            return View(transactionViewModel);
        }

        //URL: Transaction/SlipTransactions
        public ActionResult SlipTransactions()
        {
            //Creating and initializing viewmodel object
            TransactionViewModel transactionViewModel = new TransactionViewModel()
            {
                Mode = "Slip",
                TransactionID = Guid.NewGuid()
            };
            return View(transactionViewModel);
        }

        public ActionResult TransactionHome()
        {
            //Creating and initializing viewmodel object
            TransactionViewModel transactionViewModel = new TransactionViewModel()
            {
                
                TransactionID = Guid.NewGuid()
            };
            return View(transactionViewModel);
        }

        public async Task <ActionResult> Index()
        {
            //Creating object of PersonsBL
            TransactionBL transactionBL = new TransactionBL();

            //Getting list of persons from PersonsBL
            List<Transaction> transactions =await transactionBL.GetAllTransactionBL();

            //Create an empty collection of PersonViewModel
            List<TransactionViewModel> transactionsVM = new List<TransactionViewModel>();

            //Migrate (copy) data from EntityModel collection to ViewModel collection
            foreach (var item in transactions)
            {
                TransactionViewModel transactionVM = new TransactionViewModel() { AccountID = item.AccountID, Amount = item.Amount, TypeOfTransaction = item.TypeOfTransaction, Mode = item.Mode, ChequeNumber = item.ChequeNumber };
                transactionsVM.Add(transactionVM);
            }

            //Call view & pass personVM collection to view
            return View(transactionsVM);
        }

    }
}