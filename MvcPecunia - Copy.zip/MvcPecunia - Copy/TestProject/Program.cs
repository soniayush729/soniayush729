﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Capgemini.Pecunia.DataAccessLayer;
//using System.IO;

//using Capgemini.Pecunia.Exceptions;
//using Capgemini.Pecunia.Entities;
//using Capgemini.Pecunia.Contracts.DALContracts;
//using System.Data.SqlClient;
//using System.Data;

//using Capgemini.Pecunia.Helpers;

//namespace Capgemini.Pecunia.TestProject
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            SqlConnection conn = sqlCommonClass.getConnection("ndamssql\\sqlilearn", "13th Aug CLoud PT Immersive", "sqluser", "sqluser");

//            conn.Open();
//            Console.WriteLine("connected to the database");

//            SqlCommand comm = new SqlCommand("TeamF.CreditBalance", conn);

//            //Guid accID;
//            //Guid.TryParse("bdc8e59d-f8ac-4cd6-92eb-4c3ed5baacf6", out accID);
//            SqlParameter param1 = new SqlParameter("@accountID", accountID);
//            param1.SqlDbType = SqlDbType.UniqueIdentifier;

//            SqlParameter param3 = new SqlParameter("@amount", amount);
//            param3.SqlDbType = SqlDbType.Money;

//            List<SqlParameter> Params = new List<SqlParameter>();
//            Params.Add(param1);
//            Params.Add(param3);

//            comm.Parameters.AddRange(Params.ToArray());
//            comm.CommandType = CommandType.StoredProcedure;
//            comm.ExecuteNonQuery();
//            conn.Close();
//            Console.WriteLine("Transaction is donee");

//            TypeOfTranscation typeOfTransaction;
//            Enum.TryParse("Debit", out typeOfTransaction);
//            ModeOfTransaction modeOfTransaction;
//            Enum.TryParse("WithdrawalSlip", out modeOfTransaction);
//            StoreTransactionRecord(accountID, amount, typeOfTransaction, modeOfTransaction, null);
//        }
//    }
//}
